package ru.sfedu.Sync.utils;

public enum ResultType {
    OK,
    ERROR
}
